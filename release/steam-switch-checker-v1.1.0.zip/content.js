(() => {
  'use strict';

  const BOX_ID = 'ssc-checker-box';
  const SEARCH_BASE = 'https://eshop-prices.com/games?q=';
  const GAME_BASE = 'https://eshop-prices.com';
  let lastUrl = location.href;
  let renderToken = 0;

  const STRINGS = {
    en: {
      dbTitle: 'Nintendo eShop Lowest Price',
      checking: 'Searching eShop-Prices for',
      foundTitle: 'Best Nintendo eShop price found',
      matchedLabel: 'Matched game',
      cheapestLabel: 'Cheapest store',
      cheapestInLabel: 'Cheapest in',
      openEntry: 'View game details',
      openResults: 'See search results',
      noMatch: 'No reliable match found on eShop-Prices',
      notFound: 'No result found on eShop-Prices',
      manualSearch: 'Search manually on eShop-Prices',
      error: 'Price check failed',
      unknownTitle: 'Game title unavailable',
    },
    tr: {
      dbTitle: 'Nintendo eShop En Ucuz Fiyat',
      checking: 'eShop-Prices uzerinde araniyor:',
      foundTitle: 'En iyi Nintendo eShop fiyati bulundu',
      matchedLabel: 'Eslestirilen oyun',
      cheapestLabel: 'En ucuz magaza',
      cheapestInLabel: 'En ucuz ulke',
      openEntry: 'Oyun detayini ac',
      openResults: 'Arama sonuclarini gor',
      noMatch: 'eShop-Prices uzerinde guvenilir eslesme bulunamadi',
      notFound: 'eShop-Prices uzerinde sonuc bulunamadi',
      manualSearch: 'eShop-Prices uzerinde manuel ara',
      error: 'Fiyat kontrolu basarisiz',
      unknownTitle: 'Oyun adi alinamadi',
    },
  };

  function t(lang) {
    const base = (lang || '').split('-')[0];
    return { ...STRINGS.en, ...(STRINGS[base] || {}), ...(STRINGS[lang] || {}) };
  }

  async function getSettings() {
    const result = await chrome.storage.sync.get({ language: 'en', currency: 'TRY' });
    return {
      language: result.language || 'en',
      currency: (result.currency || 'TRY').toUpperCase(),
    };
  }

  function escapeHtml(str) {
    return String(str)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function getGameTitle() {
    const titleEl = document.querySelector('#appHubAppName');
    if (titleEl?.textContent?.trim()) return titleEl.textContent.trim();

    const ogTitle = document.querySelector('meta[property="og:title"]')?.content?.trim();
    if (ogTitle) return ogTitle.replace(/\s+on Steam$/i, '').trim();

    const docTitle = document.title.replace(/\s*on Steam\s*$/i, '').trim();
    return docTitle || null;
  }

  function normalizeText(text) {
    return (text || '')
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[™®©:|/\\\-–—_.,'"()\[\]!]/g, ' ')
      .replace(/\b(deluxe|ultimate|complete|definitive|gold|collector'?s|game of the year|goty|bundle|demo|soundtrack|edition|remastered|remake|digital|pack|collection)\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function scoreMatch(steamTitle, candidateTitle) {
    const s = normalizeText(steamTitle);
    const c = normalizeText(candidateTitle);
    if (!s || !c) return 0;
    if (s === c) return 100;
    if (c.includes(s)) return 92;
    if (s.includes(c)) return 84;

    const sWords = new Set(s.split(' ').filter(Boolean));
    const cWords = new Set(c.split(' ').filter(Boolean));
    let common = 0;

    for (const word of sWords) {
      if (word.length > 2 && cWords.has(word)) common++;
    }

    const ratio = common / Math.max(1, Math.min(sWords.size, cWords.size));
    return Math.round(ratio * 75);
  }

  function parsePriceNumber(priceText) {
    if (!priceText) return Number.POSITIVE_INFINITY;
    const raw = priceText.replace(/\s/g, '');
    const only = raw.replace(/[^\d.,-]/g, '');
    if (!only) return Number.POSITIVE_INFINITY;

    const lastDot = only.lastIndexOf('.');
    const lastComma = only.lastIndexOf(',');
    let normalized = only;

    if (lastComma > lastDot) {
      normalized = only.replace(/\./g, '').replace(',', '.');
    } else if (lastDot > lastComma) {
      normalized = only.replace(/,/g, '');
    } else {
      normalized = only.replace(',', '.');
    }

    const value = Number.parseFloat(normalized);
    return Number.isFinite(value) ? value : Number.POSITIVE_INFINITY;
  }

  const ICON = {
    check: `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="7" fill="rgba(76,175,130,0.18)"/><path d="M4.5 8.5l2.5 2.5 4.5-5" stroke="#4caf82" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    warning: `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="7" fill="rgba(224,168,58,0.15)"/><path d="M8 5v4M8 11v.5" stroke="#e0a83a" stroke-width="1.7" stroke-linecap="round"/></svg>`,
    cross: `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="7" fill="rgba(224,92,92,0.13)"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5" stroke="#e05c5c" stroke-width="1.7" stroke-linecap="round"/></svg>`,
    spinner: `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="ssc-spin"><circle cx="8" cy="8" r="6" stroke="rgba(255,255,255,0.15)" stroke-width="1.8"/><path d="M8 2a6 6 0 016 6" stroke="#5b8ef0" stroke-width="1.8" stroke-linecap="round"/></svg>`,
    external: `<svg width="11" height="11" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 9L9 2M6 2h3v3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    store: `<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="1" y="2.5" width="11" height="9" rx="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M1.5 5.2h10" stroke="currentColor" stroke-width="1.2"/></svg>`,
  };

  const STYLES = `
    #${BOX_ID} {
      margin: 14px 0;
      font-family: -apple-system, 'Segoe UI', system-ui, sans-serif;
      font-size: 13px;
      line-height: 1.5;
    }
    #${BOX_ID} .ssc-card {
      background: #0e1117;
      border: 1px solid rgba(255,255,255,0.09);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 24px rgba(0,0,0,0.35);
    }
    #${BOX_ID} .ssc-header {
      display: flex;
      align-items: center;
      gap: 9px;
      padding: 10px 14px;
      background: #161b27;
      border-bottom: 1px solid rgba(255,255,255,0.07);
    }
    #${BOX_ID} .ssc-header-title {
      font-size: 12px;
      font-weight: 600;
      color: rgba(255,255,255,0.55);
      letter-spacing: 0.06em;
      text-transform: uppercase;
      flex: 1;
    }
    #${BOX_ID} .ssc-header-badge {
      font-size: 10px;
      color: rgba(255,255,255,0.3);
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 20px;
      padding: 1px 8px;
    }
    #${BOX_ID} .ssc-body { padding: 13px 14px; }
    #${BOX_ID} .ssc-status-row { display: flex; align-items: flex-start; gap: 9px; }
    #${BOX_ID} .ssc-icon { flex-shrink: 0; margin-top: 1px; }
    #${BOX_ID} .ssc-status-text { flex: 1; min-width: 0; color: #e8eaf0; }
    #${BOX_ID} .ssc-title-line { font-size: 13px; font-weight: 600; color: #e8eaf0; margin-bottom: 2px; }
    #${BOX_ID} .ssc-subtitle { font-size: 12px; color: rgba(255,255,255,0.55); }
    #${BOX_ID} .ssc-pill {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 11px;
      font-weight: 500;
      padding: 2px 8px;
      border-radius: 20px;
      margin-top: 7px;
      background: rgba(91,142,240,0.16);
      color: #7aadf5;
      border: 1px solid rgba(91,142,240,0.28);
    }
    #${BOX_ID} .ssc-divider { height: 1px; background: rgba(255,255,255,0.06); margin: 11px 0; }
    #${BOX_ID} .ssc-links { display: flex; gap: 8px; flex-wrap: wrap; }
    #${BOX_ID} .ssc-link-btn {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      text-decoration: none;
      transition: background 0.15s;
    }
    #${BOX_ID} .ssc-link-primary {
      background: rgba(91,142,240,0.15);
      color: #7aadf5;
      border: 1px solid rgba(91,142,240,0.25);
    }
    #${BOX_ID} .ssc-link-primary:hover { background: rgba(91,142,240,0.25); }
    #${BOX_ID} .ssc-link-secondary {
      background: rgba(255,255,255,0.04);
      color: rgba(255,255,255,0.5);
      border: 1px solid rgba(255,255,255,0.08);
    }
    #${BOX_ID} .ssc-link-secondary:hover {
      background: rgba(255,255,255,0.08);
      color: rgba(255,255,255,0.7);
    }
    #${BOX_ID} .ssc-searching { color: rgba(255,255,255,0.5); font-size: 12px; }
    @keyframes ssc-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    #${BOX_ID} .ssc-spin { animation: ssc-spin 0.9s linear infinite; }
  `;

  function injectStyles() {
    if (document.getElementById('ssc-styles')) return;
    const style = document.createElement('style');
    style.id = 'ssc-styles';
    style.textContent = STYLES;
    document.head.appendChild(style);
  }

  function createBox(strings, title) {
    injectStyles();
    const box = document.createElement('div');
    box.id = BOX_ID;
    box.innerHTML = `
      <div class="ssc-card">
        <div class="ssc-header">
          ${ICON.store}
          <div class="ssc-header-title">${escapeHtml(strings.dbTitle)}</div>
          <div class="ssc-header-badge">eShop-Prices</div>
        </div>
        <div class="ssc-body">
          <div class="ssc-status-row">
            <div class="ssc-icon">${ICON.spinner}</div>
            <div class="ssc-status-text">
              <div class="ssc-searching">
                ${escapeHtml(strings.checking)} <strong style="color:rgba(255,255,255,0.7)">${escapeHtml(title)}</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    return box;
  }

  function insertBox(box) {
    const anchors = [
      document.querySelector('.game_area_purchase'),
      document.querySelector('.rightcol.game_meta_data'),
      document.querySelector('.glance_ctn_responsive_left'),
      document.querySelector('.page_content_ctn'),
    ].filter(Boolean);

    const existing = document.getElementById(BOX_ID);
    if (existing) existing.remove();

    if (anchors[0]?.parentNode) {
      anchors[0].parentNode.insertBefore(box, anchors[0]);
    } else {
      document.body.prepend(box);
    }
  }

  function setBody(iconHtml, mainHtml, extraHtml = '') {
    const card = document.querySelector(`#${BOX_ID} .ssc-body`);
    if (!card) return;
    card.innerHTML = `
      <div class="ssc-status-row">
        <div class="ssc-icon">${iconHtml}</div>
        <div class="ssc-status-text">${mainHtml}</div>
      </div>
      ${extraHtml ? `<div class="ssc-divider"></div>${extraHtml}` : ''}
    `;
  }

  async function fetchPage(url) {
    const response = await chrome.runtime.sendMessage({ type: 'FETCH_PAGE', url });
    if (!response?.ok) {
      throw new Error(response?.error || `HTTP ${response?.status || 'unknown'}`);
    }
    return response.text;
  }

  function parseSearchResults(html, steamTitle) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const links = [...doc.querySelectorAll('a[href^="/games/"]')];
    const seen = new Set();
    const results = [];

    for (const a of links) {
      const href = a.getAttribute('href') || '';
      if (!/^\/games\/\d+-/i.test(href)) continue;

      const absoluteUrl = new URL(href, GAME_BASE).href;
      if (seen.has(absoluteUrl)) continue;
      seen.add(absoluteUrl);

      const imgTitle = a.querySelector('img[alt]')?.getAttribute('alt')?.trim();
      let title = imgTitle || '';
      if (!title) {
        title = (a.textContent || '').replace(/\s+/g, ' ').trim();
        title = title.split(' Released on ')[0].trim();
      }
      if (!title) continue;

      results.push({
        title,
        href: absoluteUrl,
        score: scoreMatch(steamTitle, title),
      });
    }

    return results.sort((a, b) => b.score - a.score);
  }

  function parseCheapestOffer(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const rows = [...doc.querySelectorAll('tr')];

    let best = null;

    for (const row of rows) {
      const cells = [...row.querySelectorAll('td')]
        .map((td) => td.textContent.replace(/\s+/g, ' ').trim())
        .filter(Boolean);

      if (cells.length < 2) continue;

      let country = '';
      let priceText = '';

      for (const cell of cells) {
        if (!country && /^[A-Za-z][A-Za-z\s'().-]{1,40}$/.test(cell) && !/gift cards|code available|advertisement/i.test(cell)) {
          country = cell;
          continue;
        }

        if (!priceText && /(?:[A-Z]{3}\s*\d|[€$£¥₺₽₴₫₹₩₪]|\d[\d.,]+\d)/.test(cell) && !/released on|metacritic/i.test(cell)) {
          priceText = cell;
        }
      }

      if (!country || !priceText) continue;

      const numeric = parsePriceNumber(priceText);
      if (!Number.isFinite(numeric)) continue;

      if (!best || numeric < best.numeric) {
        best = { country, priceText, numeric };
      }
    }

    return best;
  }

  async function searchEshopPrices(title, currency) {
    const searchUrl = `${SEARCH_BASE}${encodeURIComponent(title)}&currency=${encodeURIComponent(currency)}`;
    const searchHtml = await fetchPage(searchUrl);
    const results = parseSearchResults(searchHtml, title);
    const bestGame = results.find((r) => r.score >= 65) || null;

    if (!bestGame) {
      return { searchUrl, results, bestGame: null, cheapest: null };
    }

    const gameUrl = `${bestGame.href}${bestGame.href.includes('?') ? '&' : '?'}currency=${encodeURIComponent(currency)}`;
    const gameHtml = await fetchPage(gameUrl);
    const cheapest = parseCheapestOffer(gameHtml);

    return {
      searchUrl,
      results,
      bestGame: { ...bestGame, href: gameUrl },
      cheapest,
    };
  }

  async function render() {
    const token = ++renderToken;
    const { language, currency } = await getSettings();
    const strings = t(language);
    const title = getGameTitle();

    if (!title) {
      document.getElementById(BOX_ID)?.remove();
      return;
    }

    const box = createBox(strings, title);
    insertBox(box);

    try {
      const data = await searchEshopPrices(title, currency);
      if (token !== renderToken) return;

      if (!data.results.length) {
        setBody(
          ICON.cross,
          `<div class="ssc-title-line">${escapeHtml(strings.notFound)}</div>`,
          `<div class="ssc-links">
            <a href="${escapeHtml(data.searchUrl)}" target="_blank" rel="noopener noreferrer" class="ssc-link-btn ssc-link-secondary">
              ${escapeHtml(strings.manualSearch)} ${ICON.external}
            </a>
          </div>`
        );
        return;
      }

      if (!data.bestGame || !data.cheapest) {
        setBody(
          ICON.warning,
          `<div class="ssc-title-line">${escapeHtml(strings.noMatch)}</div>`,
          `<div class="ssc-links">
            <a href="${escapeHtml(data.searchUrl)}" target="_blank" rel="noopener noreferrer" class="ssc-link-btn ssc-link-secondary">
              ${escapeHtml(strings.openResults)} ${ICON.external}
            </a>
          </div>`
        );
        return;
      }

      setBody(
        ICON.check,
        `<div class="ssc-title-line">${escapeHtml(strings.foundTitle)}</div>
         <div class="ssc-subtitle">${escapeHtml(strings.matchedLabel)}: ${escapeHtml(data.bestGame.title)}</div>
         <div class="ssc-pill">${ICON.store} ${escapeHtml(strings.cheapestInLabel)}: ${escapeHtml(data.cheapest.country)}</div>`,
        `<div class="ssc-subtitle" style="margin-bottom:10px;">
          ${escapeHtml(strings.cheapestLabel)}: <strong>${escapeHtml(data.cheapest.priceText)}</strong> (${escapeHtml(data.cheapest.country)})
        </div>
        <div class="ssc-links">
          <a href="${escapeHtml(data.bestGame.href)}" target="_blank" rel="noopener noreferrer" class="ssc-link-btn ssc-link-primary">
            ${escapeHtml(strings.openEntry)} ${ICON.external}
          </a>
          <a href="${escapeHtml(data.searchUrl)}" target="_blank" rel="noopener noreferrer" class="ssc-link-btn ssc-link-secondary">
            ${escapeHtml(strings.openResults)} ${ICON.external}
          </a>
        </div>`
      );
    } catch (error) {
      if (token !== renderToken) return;
      setBody(
        ICON.warning,
        `<div class="ssc-title-line" style="color:#e05c5c">${escapeHtml(strings.error)}</div>
         <div class="ssc-subtitle">${escapeHtml(error?.message || 'Unknown error')}</div>`
      );
    }
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'SET_SETTINGS' || message?.type === 'SET_LANGUAGE') {
      render();
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    if (changes.language || changes.currency) render();
  });

  render();

  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      render();
    }
  }, 1000);
})();
